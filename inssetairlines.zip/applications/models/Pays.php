<?php
    class Table_Pays extends Zend_Db_Table_Abstract
    {
        protected $_name = 'pays';
        protected $_primary = 'idPays';
    }