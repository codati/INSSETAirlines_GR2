<?php
/**
 * Liste tous les requires à faire pour tous les fichiers de fonctions.
 */

require_once(APPLICATION_PATH.'/functions/date.php'); //Les dates
require_once(APPLICATION_PATH.'/functions/sessions.php'); //Les sessions
require_once(APPLICATION_PATH.'/functions/services.php'); //Les services

?>