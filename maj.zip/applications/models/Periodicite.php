<?php
    class Table_Periodicite extends Zend_Db_Table_Abstract
    {
        protected $_name = 'periodicite';
        protected $_primary = 'idPeriode';
    }